#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(int imageID, double startX, double startY, int dir, double size, StudentWorld *studentWorld)
    : GraphObject(imageID, startX, startY, dir, size)
{
    m_StudentWorld = studentWorld;
}

StudentWorld *Actor::getWorld()
{
    return m_StudentWorld;
}

void Actor::doSomething()
{
}

Wall::Wall(double startX, double startY, int dir, double size, StudentWorld *studentWorld)
    : Actor(IID_WALL, startX, startY, dir, size, studentWorld)
{
    setVisible(true);
}

Avatar::Avatar(double startX, double startY, int dir, double size, StudentWorld *studentWorld)
    : Actor(IID_PLAYER, startX, startY, dir, size, studentWorld)
{
    setVisible(true);
}

void Avatar::doSomething()
{
    int ch;
    if (getWorld()->getKey(ch))
    {
        // StudentWorld *world = getWorld();
        // Level lev = world->getLevel();
        Level lev = getWorld()->getLevel();

        switch (ch)
        {
        case KEY_PRESS_LEFT:
            // if getContents of x-1,y is not a wall
            if (lev.getContentsOf(getX() - 1, getY()) != Level::wall)
            {
                setDirection(left);
                moveTo(getX() - 1, getY());
            }
            break;
        case KEY_PRESS_RIGHT:
            if (lev.getContentsOf(getX() + 1, getY()) != Level::wall)
            {
                setDirection(right);
                moveTo(getX() + 1, getY());
            }
            break;
        case KEY_PRESS_UP:
            if (lev.getContentsOf(getX(), getY() + 1) != Level::wall)
            {
                setDirection(up);
                moveTo(getX(), getY() + 1);
            }
            break;
        case KEY_PRESS_DOWN:
            if (lev.getContentsOf(getX(), getY() - 1) != Level::wall)
            {
                setDirection(down);
                moveTo(getX(), getY() - 1);
            }
            break;
        case KEY_PRESS_SPACE:
            break;
        }
    }
}
