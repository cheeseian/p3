#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
using namespace std;

GameWorld *createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
    : GameWorld(assetPath), m_lev(assetPath)
{
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

Level StudentWorld::getLevel()
{
    return m_lev;
}
int StudentWorld::init()
{
    // Loading current level
    string curLevel = "level01.txt";
    Level::LoadResult result = m_lev.loadLevel(curLevel);
    if (result == Level::load_fail_file_not_found)
        cerr << "Could not find level00.txt data file\n";
    else if (result == Level::load_fail_bad_format)
        cerr << "Your level was improperly formatted\n";
    else if (result == Level::load_success)
    {
        for (int x = 0; x < VIEW_WIDTH; x++)
        {
            for (int y = 0; y < VIEW_HEIGHT; y++)
            {
                Level::MazeEntry ge = m_lev.getContentsOf(x, y);
                switch (ge)
                {
                case Level::empty:
                    break;
                case Level::exit:
                    break;
                case Level::player:
                {
                    Avatar *avatar = new Avatar(x, y, 0, 1, this);
                    actors.push_back(avatar);
                    break;
                }
                case Level::horiz_ragebot:
                    break;
                case Level::vert_ragebot:
                    break;
                case Level::thiefbot_factory:
                    break;
                case Level::mean_thiefbot_factory:
                    break;
                case Level::wall:
                {
                    Wall *wall = new Wall(x, y, 0, 1, this);
                    actors.push_back(wall);
                    break;
                }
                case Level::marble:
                    break;
                case Level::pit:
                    break;
                case Level::crystal:
                    break;
                case Level::restore_health:
                    break;
                case Level::extra_life:
                    break;
                case Level::ammo:
                    break;
                }
            }
        }
    }

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    vector<Actor *>::iterator it;
    it = actors.begin();

    while (it != actors.end())
    {
        (*it)->doSomething();
        it++;
    }

    setGameStatText("Game will end when you type q");

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    vector<Actor *>::iterator it;
    it = actors.begin();

    while (it != actors.end())
    {
        delete *it;
        it = actors.erase(it);
    }
}

